import api from './api';
import { getTodayLocalISO } from '../utils/date';
import { workspaceService } from './workspaceService';
import { projectService } from './projectService';
import { taskService } from './taskService';

export const dashboardService = {
  async getDashboard() {
    const today = getTodayLocalISO();

    // 1. If backend implements GET /api/dashboard, use it
    if (import.meta.env.VITE_USE_MOCK_DASHBOARD !== 'true') {
      try {
        const response = await api.get('/api/dashboard', { params: { today } });
        return response.data;
      } catch (err) {
        // Fall through to real database aggregation if endpoint is 404/501
        if (!err.response || (err.response.status !== 404 && err.response.status !== 501)) {
          throw err;
        }
      }
    }

    // 2. Aggregate REAL data from existing database endpoints
    const workspaces = await workspaceService.getAll();
    const workspaceList = workspaces || [];

    // Fetch projects for all workspaces in parallel
    const projectsNested = await Promise.all(
      workspaceList.map(async (ws) => {
        try {
          const projs = await projectService.getByWorkspace(ws.id, 'ACTIVE');
          return projs.map((p) => ({ ...p, workspaceName: ws.name }));
        } catch {
          return [];
        }
      })
    );
    const activeProjects = projectsNested.flat();

    // Fetch board tasks for active projects to get assigned & recent tasks
    const tasksNested = await Promise.all(
      activeProjects.slice(0, 10).map(async (p) => {
        try {
          const board = await taskService.getBoard(p.id);
          const allTasks = Object.values(board.columns || {}).flat();
          return allTasks.map((t) => ({
            ...t,
            projectId: p.id,
            projectName: p.name,
            workspaceId: p.workspaceId,
            workspaceName: p.workspaceName
          }));
        } catch {
          return [];
        }
      })
    );
    const allTasks = tasksNested.flat();

    // Determine current user ID from /api/me or auth
    let currentUserId = null;
    try {
      const meRes = await api.get('/api/me');
      currentUserId = meRes.data?.id;
    } catch {
      // ignore
    }

    // Filter tasks assigned to current user and not DONE
    const in7Days = new Date();
    in7Days.setDate(in7Days.getDate() + 7);
    const in7DaysISO = in7Days.toISOString().split('T')[0];

    const myTasks = allTasks
      .filter((t) => t.assigneeId === currentUserId && t.status !== 'DONE')
      .sort((a, b) => {
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return a.dueDate.localeCompare(b.dueDate);
      });

    const openTasksCount = myTasks.length;
    const dueSoonCount = myTasks.filter(
      (t) => t.dueDate && t.dueDate >= today && t.dueDate <= in7DaysISO
    ).length;
    const overdueCount = myTasks.filter((t) => t.dueDate && t.dueDate < today).length;

    // Recent task updates
    const recentTasks = [...allTasks]
      .sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''))
      .slice(0, 8);

    // Recent active projects
    const recentProjects = [...activeProjects]
      .sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''))
      .slice(0, 5);

    return {
      counts: {
        workspaces: workspaceList.length,
        activeProjects: activeProjects.length,
        openTasks: openTasksCount,
        dueSoon: dueSoonCount,
        overdue: overdueCount
      },
      myTasks: myTasks.slice(0, 8),
      recentProjects,
      recentTasks
    };
  }
};