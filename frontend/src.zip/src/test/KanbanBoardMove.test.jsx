import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { KanbanBoard } from '../pages/ProjectDetail/KanbanBoard';
import { taskService } from '../services/taskService';
import { ToastProvider } from '../context/ToastContext';

describe('KanbanBoard Move & Rollback', () => {
  const initialBoardData = {
    columns: {
      TODO: [
        { id: 1, title: 'Sample Move Task', status: 'TODO', priority: 'LOW', version: 1 }
      ],
      IN_PROGRESS: [],
      IN_REVIEW: [],
      DONE: []
    }
  };

  it('renders initial task in correct column', () => {
    render(
      <ToastProvider>
        <KanbanBoard
          boardData={initialBoardData}
          onOpenTask={vi.fn()}
          canMoveTask={() => true}
          isArchived={false}
          onReloadBoard={vi.fn()}
          projectId={10}
        />
      </ToastProvider>
    );

    expect(screen.getByText('Sample Move Task')).toBeInTheDocument();
    expect(screen.getByText('To Do')).toBeInTheDocument();
  });
});