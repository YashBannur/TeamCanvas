import { describe, it, expect } from 'vitest';
import {
  canManageWorkspace,
  canDeleteWorkspace,
  canInviteRole,
  canAssignTask,
  canEditTask,
  canMoveTask,
  canDeleteTask
} from '../utils/permissions';
import { WORKSPACE_ROLES } from '../constants/roles';

describe('Permissions Logic', () => {
  it('identifies workspace management permissions correctly', () => {
    expect(canManageWorkspace(WORKSPACE_ROLES.OWNER)).toBe(true);
    expect(canManageWorkspace(WORKSPACE_ROLES.ADMIN)).toBe(true);
    expect(canManageWorkspace(WORKSPACE_ROLES.MEMBER)).toBe(false);

    expect(canDeleteWorkspace(WORKSPACE_ROLES.OWNER)).toBe(true);
    expect(canDeleteWorkspace(WORKSPACE_ROLES.ADMIN)).toBe(false);
  });

  it('enforces invitation role constraints', () => {
    // Owner can invite Admin or Member
    expect(canInviteRole(WORKSPACE_ROLES.OWNER, WORKSPACE_ROLES.ADMIN)).toBe(true);
    expect(canInviteRole(WORKSPACE_ROLES.OWNER, WORKSPACE_ROLES.MEMBER)).toBe(true);
    // Admin can only invite Member
    expect(canInviteRole(WORKSPACE_ROLES.ADMIN, WORKSPACE_ROLES.ADMIN)).toBe(false);
    expect(canInviteRole(WORKSPACE_ROLES.ADMIN, WORKSPACE_ROLES.MEMBER)).toBe(true);
  });

  it('restricts task assignment exclusively to Owner and Admin', () => {
    expect(canAssignTask(WORKSPACE_ROLES.OWNER)).toBe(true);
    expect(canAssignTask(WORKSPACE_ROLES.ADMIN)).toBe(true);
    expect(canAssignTask(WORKSPACE_ROLES.MEMBER)).toBe(false);
  });

  it('prevents non-owners/non-reporters from editing task details', () => {
    const task = { id: 1, reporterId: 10, assigneeId: 20 };

    // Owner can edit
    expect(canEditTask({ myRole: WORKSPACE_ROLES.OWNER, task, currentUserId: 99 })).toBe(true);
    // Reporter can edit
    expect(canEditTask({ myRole: WORKSPACE_ROLES.MEMBER, task, currentUserId: 10 })).toBe(true);
    // Assignee (not reporter) cannot edit
    expect(canEditTask({ myRole: WORKSPACE_ROLES.MEMBER, task, currentUserId: 20 })).toBe(false);
    // Archived project blocks edits regardless of role
    expect(canEditTask({ myRole: WORKSPACE_ROLES.OWNER, task, currentUserId: 10, isProjectArchived: true })).toBe(false);
  });

  it('validates task deletion rights', () => {
    const task = { id: 1, reporterId: 10 };
    expect(canDeleteTask({ myRole: WORKSPACE_ROLES.OWNER, task, currentUserId: 99 })).toBe(true);
    expect(canDeleteTask({ myRole: WORKSPACE_ROLES.MEMBER, task, currentUserId: 10 })).toBe(true);
    expect(canDeleteTask({ myRole: WORKSPACE_ROLES.MEMBER, task, currentUserId: 99 })).toBe(false);
  });
});