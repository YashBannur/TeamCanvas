import { useAuth } from '../context/AuthContext';
import { CardSkeleton, Skeleton } from '../components/ui/Skeleton';
import './Dashboard.css';

export default function Dashboard() {
  const { user, status } = useAuth();

  if (status === 'loading') {
    return (
      <div className="dashboard-page">
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <Skeleton width="220px" height="32px" />
          <Skeleton width="340px" height="18px" />
        </div>
        <div className="stats-grid">
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
          <CardSkeleton />
        </div>
        <div className="dashboard-grid">
          <CardSkeleton />
          <CardSkeleton />
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <header className="dashboard-header">
        <div>
          <h1 className="dashboard-title">
            Welcome back{user?.name ? `, ${user.name}` : ''}!
          </h1>
          <p className="dashboard-subtitle">
            Here is a snapshot of your workspace activity and assignments.
          </p>
        </div>
      </header>

      <div className="stats-grid">
        <div className="stat-card stat-card--primary">
          <span className="stat-card__label">Workspaces</span>
          <span className="stat-card__value">0</span>
        </div>
        <div className="stat-card">
          <span className="stat-card__label">Active Projects</span>
          <span className="stat-card__value">0</span>
        </div>
        <div className="stat-card stat-card--warning">
          <span className="stat-card__label">Assigned Tasks</span>
          <span className="stat-card__value">0</span>
        </div>
        <div className="stat-card stat-card--danger">
          <span className="stat-card__label">Overdue Tasks</span>
          <span className="stat-card__value">0</span>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="dashboard-panel">
          <div className="dashboard-panel__header">
            <h2 className="dashboard-panel__title">Assigned to Me</h2>
          </div>
          <div className="dashboard-list">
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', margin: 0 }}>
              No tasks currently assigned.
            </p>
          </div>
        </div>

        <div className="dashboard-panel">
          <div className="dashboard-panel__header">
            <h2 className="dashboard-panel__title">Recent Projects</h2>
          </div>
          <div className="dashboard-list">
            <p style={{ color: 'var(--text-secondary)', fontSize: '0.9rem', margin: 0 }}>
              No active projects found.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}