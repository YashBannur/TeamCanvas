import { useState, useEffect } from 'react';
import {
  DndContext,
  PointerSensor,
  KeyboardSensor,
  useSensor,
  useSensors,
  closestCorners
} from '@dnd-kit/core';
import { sortableKeyboardCoordinates } from '@dnd-kit/sortable';
import { KanbanColumn } from './KanbanColumn';
import { TASK_STATUS_ORDER } from '../../constants/taskStatus';
import { taskService } from '../../services/taskService';
import { useToast } from '../../context/ToastContext';
import { parseApiError } from '../../utils/apiError';

export function KanbanBoard({
  boardData,
  onOpenTask,
  canMoveTask,
  isArchived,
  onReloadBoard,
  projectId
}) {
  const { error: showErrorToast, success } = useToast();
  const [columns, setColumns] = useState(boardData?.columns || {});

  useEffect(() => {
    if (boardData?.columns) {
      setColumns(boardData.columns);
    }
  }, [boardData]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 5
      }
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates
    })
  );

  const findColumnOfTask = (taskId) => {
    for (const [colStatus, tasks] of Object.entries(columns)) {
      if (tasks.some((t) => t.id === taskId)) {
        return colStatus;
      }
    }
    return null;
  };

  const handleDragEnd = async (event) => {
    const { active, over } = event;
    if (!over || isArchived) return;

    const activeId = active.id;
    const overId = over.id;

    const sourceColumn = findColumnOfTask(activeId);
    if (!sourceColumn) return;

    let targetColumn = null;
    let targetIndex = 0;

    if (TASK_STATUS_ORDER.includes(overId)) {
      targetColumn = overId;
      targetIndex = columns[targetColumn]?.length || 0;
    } else {
      targetColumn = findColumnOfTask(overId);
      if (!targetColumn) return;
      const overIndex = columns[targetColumn].findIndex((t) => t.id === overId);
      targetIndex = overIndex >= 0 ? overIndex : 0;
    }

    const previousColumns = { ...columns };
    const taskToMove = columns[sourceColumn].find((t) => t.id === activeId);
    if (!taskToMove) return;

    // Build optimistic columns
    const nextSourceTasks = columns[sourceColumn].filter((t) => t.id !== activeId);
    const nextTargetTasks =
      sourceColumn === targetColumn ? [...nextSourceTasks] : [...columns[targetColumn]];

    const updatedTask = { ...taskToMove, status: targetColumn };
    nextTargetTasks.splice(targetIndex, 0, updatedTask);

    const nextColumns = {
      ...columns,
      [sourceColumn]: nextSourceTasks,
      [targetColumn]: nextTargetTasks
    };

    setColumns(nextColumns);

    // Compute afterTaskId from target column
    const afterTaskId = targetIndex > 0 ? nextTargetTasks[targetIndex - 1].id : null;

    try {
      await taskService.move(activeId, {
        status: targetColumn,
        afterTaskId: afterTaskId || undefined,
        version: taskToMove.version
      });
    } catch (err) {
      setColumns(previousColumns);
      const parsed = parseApiError(err);
      if (parsed.status === 409 || parsed.status === 400) {
        showErrorToast('Board updated by someone else. Refreshing...');
        onReloadBoard();
      } else {
        showErrorToast(parsed.message || 'Failed to move task');
      }
    }
  };

  const handleMoveToStatus = async (task, targetStatus) => {
    const sourceCol = task.status;
    const previousColumns = { ...columns };

    const nextSource = columns[sourceCol].filter((t) => t.id !== task.id);
    const nextTarget = [...columns[targetStatus], { ...task, status: targetStatus }];

    setColumns({
      ...columns,
      [sourceCol]: nextSource,
      [targetStatus]: nextTarget
    });

    const targetList = columns[targetStatus];
    const afterTaskId = targetList.length > 0 ? targetList[targetList.length - 1].id : null;

    try {
      await taskService.move(task.id, {
        status: targetStatus,
        afterTaskId: afterTaskId || undefined,
        version: task.version
      });
      success(`Task moved to ${targetStatus}`);
      onReloadBoard();
    } catch (err) {
      setColumns(previousColumns);
      const parsed = parseApiError(err);
      showErrorToast(parsed.message || 'Failed to move task');
      onReloadBoard();
    }
  };

  const handleQuickAdd = async (status, title) => {
    try {
      await taskService.create(projectId, { title, status });
      success('Task created');
      onReloadBoard();
    } catch (err) {
      const parsed = parseApiError(err);
      showErrorToast(parsed.message || 'Failed to create task');
    }
  };

  return (
    <div className="kanban-board-scroll">
      <DndContext
        sensors={sensors}
        collisionDetection={closestCorners}
        onDragEnd={handleDragEnd}
      >
        <div className="kanban-board">
          {TASK_STATUS_ORDER.map((statusKey) => (
            <KanbanColumn
              key={statusKey}
              status={statusKey}
              tasks={columns[statusKey] || []}
              onOpenTask={onOpenTask}
              canMoveTask={canMoveTask}
              isArchived={isArchived}
              onQuickAddTask={handleQuickAdd}
              onMoveToStatus={handleMoveToStatus}
            />
          ))}
        </div>
      </DndContext>
    </div>
  );
}