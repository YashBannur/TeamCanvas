import { WORKSPACE_ROLES } from '../constants/roles';

export function canManageWorkspace(role) {
  return role === WORKSPACE_ROLES.OWNER || role === WORKSPACE_ROLES.ADMIN;
}

export function canDeleteWorkspace(role) {
  return role === WORKSPACE_ROLES.OWNER;
}

export function canInviteRole(myRole, targetRole) {
  if (myRole === WORKSPACE_ROLES.OWNER) {
    return targetRole === WORKSPACE_ROLES.ADMIN || targetRole === WORKSPACE_ROLES.MEMBER;
  }
  if (myRole === WORKSPACE_ROLES.ADMIN) {
    return targetRole === WORKSPACE_ROLES.MEMBER;
  }
  return false;
}

export function canChangeMemberRole(myRole) {
  return myRole === WORKSPACE_ROLES.OWNER;
}

export function canRemoveMember(myRole, targetRole, isSelf) {
  if (isSelf) return false;
  if (myRole === WORKSPACE_ROLES.OWNER) return true;
  if (myRole === WORKSPACE_ROLES.ADMIN) {
    return targetRole === WORKSPACE_ROLES.MEMBER;
  }
  return false;
}

export function canLeaveWorkspace(myRole) {
  return myRole === WORKSPACE_ROLES.ADMIN || myRole === WORKSPACE_ROLES.MEMBER;
}

export function canManageProjects(role) {
  return role === WORKSPACE_ROLES.OWNER || role === WORKSPACE_ROLES.ADMIN;
}

// Only OWNER or ADMIN can assign, reassign, or unassign tasks
export function canAssignTask(myRole) {
  return myRole === WORKSPACE_ROLES.OWNER || myRole === WORKSPACE_ROLES.ADMIN;
}

// OWNER and ADMIN can edit any task; a MEMBER can only edit if they originally created/reported it
export function canEditTask({ myRole, task, currentUserId, isProjectArchived }) {
  if (isProjectArchived) return false;
  if (myRole === WORKSPACE_ROLES.OWNER || myRole === WORKSPACE_ROLES.ADMIN) return true;
  if (!task) return false;
  return task.reporterId === currentUserId;
}

// OWNER and ADMIN can move any task; assignee or reporter can move their own task across status columns
export function canMoveTask({ myRole, task, currentUserId, isProjectArchived }) {
  if (isProjectArchived) return false;
  if (myRole === WORKSPACE_ROLES.OWNER || myRole === WORKSPACE_ROLES.ADMIN) return true;
  if (!task) return false;
  return (
    task.reporterId === currentUserId ||
    task.assigneeId === currentUserId ||
    task.assigneeId === null
  );
}

// OWNER and ADMIN can delete any task; a MEMBER can delete only if they are the reporter
export function canDeleteTask({ myRole, task, currentUserId, isProjectArchived }) {
  if (isProjectArchived) return false;
  if (myRole === WORKSPACE_ROLES.OWNER || myRole === WORKSPACE_ROLES.ADMIN) return true;
  return Boolean(task && task.reporterId === currentUserId);
}