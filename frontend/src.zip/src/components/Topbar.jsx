import { useLocation } from 'react-router-dom';
import { Menu } from 'lucide-react';

const TITLES = [
  { prefix: '/dashboard', title: 'Dashboard' },
  { prefix: '/workspaces', title: 'Workspaces' },
  { prefix: '/projects', title: 'Projects' },
  { prefix: '/invitations', title: 'Invitations' },
  { prefix: '/profile', title: 'Profile' }
];

export default function Topbar({ onOpenMobileMenu = () => {} }) {
  const location = useLocation();

  const getPageTitle = () => {
    const match = TITLES.find((item) => location.pathname.startsWith(item.prefix));
    return match ? match.title : 'Dashboard';
  };

  return (
    <header className="app-topbar">
      <div className="topbar-left">
        <button
          type="button"
          className="icon-button topbar-menu-btn"
          onClick={onOpenMobileMenu}
          aria-label="Open sidebar navigation"
        >
          <Menu size={20} />
        </button>
        <div className="topbar-breadcrumbs">
          <span>TeamCanvas</span>
          <span>&rsaquo;</span>
          <strong>{getPageTitle()}</strong>
        </div>
      </div>
    </header>
  );
}