package com.teamcanvas.task;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface TaskRepository extends JpaRepository<Task, Long>, JpaSpecificationExecutor<Task> {

    /** One task with its project, reporter and assignee loaded in the same query. */
    @Query("select t from Task t join fetch t.project join fetch t.reporter left join fetch t.assignee "
            + "where t.id = :id")
    Optional<Task> findDetailedById(@Param("id") Long id);

    /**
     * The dynamic search used by the task list and the board. The entity graph loads reporter and assignee in the
     * same query, so a page of tasks does not trigger one extra query per task (no N+1).
     */
    @Override
    @EntityGraph(attributePaths = {"reporter", "assignee"})
    Page<Task> findAll(Specification<Task> spec, Pageable pageable);

    /** Highest position in a column, or -1 if the column is empty (so the next card gets 0). */
    @Query("select coalesce(max(t.sortOrder), -1) from Task t where t.project.id = :projectId and t.status = :status")
    Integer findMaxSortOrder(@Param("projectId") Long projectId, @Param("status") TaskStatus status);

    /** All cards of one Kanban column, top to bottom. */
    @Query("select t from Task t where t.project.id = :projectId and t.status = :status "
            + "order by t.sortOrder asc, t.id asc")
    List<Task> findColumn(@Param("projectId") Long projectId, @Param("status") TaskStatus status);

    /** Task totals for many projects in ONE query (used for project progress). */
    @Query("select t.project.id as projectId, count(t) as total, "
            + "sum(case when t.status = :doneStatus then 1 else 0 end) as completed "
            + "from Task t where t.project.id in :ids group by t.project.id")
    List<ProjectTaskCounts> countByProjectIds(@Param("ids") Collection<Long> ids,
                                              @Param("doneStatus") TaskStatus doneStatus);

    interface ProjectTaskCounts {
        Long getProjectId();

        Long getTotal();

        Long getCompleted();
    }
}
