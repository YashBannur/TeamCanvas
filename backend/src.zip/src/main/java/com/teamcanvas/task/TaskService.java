package com.teamcanvas.task;

import com.teamcanvas.common.exception.BadRequestException;
import com.teamcanvas.common.exception.ConflictException;
import com.teamcanvas.common.exception.ResourceNotFoundException;
import com.teamcanvas.project.Project;
import com.teamcanvas.project.ProjectRepository;
import com.teamcanvas.project.ProjectStatus;
import com.teamcanvas.security.PermissionService;
import com.teamcanvas.task.dto.CreateTaskRequest;
import com.teamcanvas.task.dto.MoveTaskRequest;
import com.teamcanvas.task.dto.TaskResponse;
import com.teamcanvas.task.dto.UpdateTaskRequest;
import com.teamcanvas.user.User;
import com.teamcanvas.workspace.WorkspaceMember;
import com.teamcanvas.workspace.WorkspaceMemberRepository;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TaskService {

    private static final String PROJECT_NOT_FOUND = "Project not found";
    private static final String TASK_NOT_FOUND = "Task not found";

    private final TaskRepository taskRepository;
    private final ProjectRepository projectRepository;
    private final WorkspaceMemberRepository memberRepository;
    private final PermissionService permissionService;

    public TaskService(TaskRepository taskRepository,
                       ProjectRepository projectRepository,
                       WorkspaceMemberRepository memberRepository,
                       PermissionService permissionService) {
        this.taskRepository = taskRepository;
        this.projectRepository = projectRepository;
        this.memberRepository = memberRepository;
        this.permissionService = permissionService;
    }

    /** Any workspace member may create a task. It goes to the bottom of its column. */
    @Transactional
    public TaskResponse create(Long projectId, Long userId, CreateTaskRequest request) {
        Project project = projectRepository.findDetailedById(projectId)
                .orElseThrow(() -> new ResourceNotFoundException(PROJECT_NOT_FOUND));
        Long workspaceId = project.getWorkspace().getId();
        WorkspaceMember member = permissionService.requireMember(workspaceId, userId, PROJECT_NOT_FOUND);
        requireProjectActive(project);
        validateDates(request.startDate(), request.dueDate());

        User assignee = resolveAssignee(workspaceId, request.assigneeId());
        TaskStatus status = request.status() == null ? TaskStatus.TODO : request.status();
        TaskPriority priority = request.priority() == null ? TaskPriority.MEDIUM : request.priority();
        int sortOrder = taskRepository.findMaxSortOrder(projectId, status) + 1;

        Task task = taskRepository.save(new Task(
                project,
                request.title().trim(),
                blankToNull(request.description()),
                status,
                priority,
                assignee,
                member.getUser(),
                request.startDate(),
                request.dueDate(),
                sortOrder));
        return TaskResponse.from(task);
    }

    @Transactional(readOnly = true)
    public TaskResponse getOne(Long taskId, Long userId) {
        return TaskResponse.from(loadForMember(taskId, userId).task());
    }

    @Transactional
    public TaskResponse update(Long taskId, Long userId, UpdateTaskRequest request) {
        TaskAccess access = loadForMember(taskId, userId);
        Task task = access.task();
        requireProjectActive(task.getProject());
        permissionService.requireCanModifyTask(access.member(), task);
        checkVersion(task, request.version());

        boolean unassign = Boolean.TRUE.equals(request.unassign());
        if (unassign && request.assigneeId() != null) {
            throw new BadRequestException("Send either assigneeId or unassign, not both");
        }

        if (request.title() != null) {
            task.setTitle(request.title().trim());
        }
        if (request.description() != null) {
            task.setDescription(blankToNull(request.description()));
        }
        if (request.priority() != null) {
            task.setPriority(request.priority());
        }
        if (unassign) {
            task.setAssignee(null);
        } else if (request.assigneeId() != null) {
            task.setAssignee(resolveAssignee(workspaceIdOf(task), request.assigneeId()));
        }
        if (request.startDate() != null) {
            task.setStartDate(request.startDate());
        }
        if (request.dueDate() != null) {
            task.setDueDate(request.dueDate());
        }
        // Validate the dates as they will be AFTER the change (a partial update can break the pair).
        validateDates(task.getStartDate(), task.getDueDate());

        // Flush now so the response carries the real new version and updatedAt.
        taskRepository.flush();
        return TaskResponse.from(task);
    }

    /**
     * Kanban move: put the task into column "status", directly below "afterTaskId" (null = top).
     * The target column is renumbered 0..n-1 so the order is always consistent.
     */
    @Transactional
    public TaskResponse move(Long taskId, Long userId, MoveTaskRequest request) {
        TaskAccess access = loadForMember(taskId, userId);
        Task task = access.task();
        requireProjectActive(task.getProject());
        permissionService.requireCanModifyTask(access.member(), task);
        checkVersion(task, request.version());

        List<Task> column = new ArrayList<>(
                taskRepository.findColumn(task.getProject().getId(), request.status()));
        column.removeIf(other -> other.getId().equals(task.getId()));

        int insertAt = 0;
        if (request.afterTaskId() != null) {
            int afterIndex = -1;
            for (int i = 0; i < column.size(); i++) {
                if (column.get(i).getId().equals(request.afterTaskId())) {
                    afterIndex = i;
                    break;
                }
            }
            if (afterIndex < 0) {
                throw new BadRequestException("afterTaskId must be a different task in the target column");
            }
            insertAt = afterIndex + 1;
        }

        task.setStatus(request.status());
        column.add(insertAt, task);
        for (int i = 0; i < column.size(); i++) {
            column.get(i).setSortOrder(i);
        }

        taskRepository.flush();
        return TaskResponse.from(task);
    }

    /** OWNER/ADMIN: any task. MEMBER: only tasks they created. */
    @Transactional
    public void delete(Long taskId, Long userId) {
        TaskAccess access = loadForMember(taskId, userId);
        Task task = access.task();
        requireProjectActive(task.getProject());
        permissionService.requireCanDeleteTask(access.member(), task);
        taskRepository.delete(task);
    }

    // ---------------------------------------------------------------- helpers

    private record TaskAccess(Task task, WorkspaceMember member) {
    }

    /**
     * Task -> project -> workspace -> is the caller a member? A missing task and a task in somebody else's
     * workspace both give the same 404, so task ids cannot be probed by changing the id in the URL.
     */
    private TaskAccess loadForMember(Long taskId, Long userId) {
        Task task = taskRepository.findDetailedById(taskId)
                .orElseThrow(() -> new ResourceNotFoundException(TASK_NOT_FOUND));
        WorkspaceMember member = permissionService.requireMember(workspaceIdOf(task), userId, TASK_NOT_FOUND);
        return new TaskAccess(task, member);
    }

    private Long workspaceIdOf(Task task) {
        return task.getProject().getWorkspace().getId();
    }

    /** The assignee must be a member of the task's workspace; verified against the database. */
    private User resolveAssignee(Long workspaceId, Long assigneeId) {
        if (assigneeId == null) {
            return null;
        }
        return memberRepository.findByWorkspaceIdAndUserId(workspaceId, assigneeId)
                .map(WorkspaceMember::getUser)
                .orElseThrow(() -> new BadRequestException("Assignee must be a member of this workspace"));
    }

    private void requireProjectActive(Project project) {
        if (project.getStatus() == ProjectStatus.ARCHIVED) {
            throw new ConflictException("This project is archived; restore it to change its tasks");
        }
    }

    private void checkVersion(Task task, Long clientVersion) {
        if (clientVersion != null && clientVersion.longValue() != task.getVersion()) {
            throw new ConflictException("This task was changed by someone else. Reload it and try again");
        }
    }

    private void validateDates(LocalDate start, LocalDate due) {
        if (start != null && due != null && due.isBefore(start)) {
            throw new BadRequestException("Due date cannot be before start date");
        }
    }

    private String blankToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
