package com.teamcanvas.security;

import com.teamcanvas.common.exception.ForbiddenException;
import com.teamcanvas.common.exception.ResourceNotFoundException;
import com.teamcanvas.task.Task;
import com.teamcanvas.workspace.WorkspaceMember;
import com.teamcanvas.workspace.WorkspaceMemberRepository;
import com.teamcanvas.workspace.WorkspaceRole;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * The single place where "may this user do this?" is decided.
 *
 *  - Not a member            -> 404 (we do not reveal that the workspace / its contents exist)
 *  - Member, role too low    -> 403 with a specific message
 *
 * The overloads with a "notFoundMessage" let callers such as the project service say "Project not found"
 * instead of "Workspace not found", without changing the rule itself.
 *
 * Always call these methods from a service method (they join its transaction), never from a controller.
 */
@Service
@Transactional(readOnly = true)
public class PermissionService {

    private static final String WORKSPACE_NOT_FOUND = "Workspace not found";

    private final WorkspaceMemberRepository memberRepository;

    public PermissionService(WorkspaceMemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    // ---------------------------------------------------------------- workspace-level rules

    /** Returns the caller's membership, or throws 404 if they are not a member of the workspace. */
    public WorkspaceMember requireMember(Long workspaceId, Long userId) {
        return requireMember(workspaceId, userId, WORKSPACE_NOT_FOUND);
    }

    public WorkspaceMember requireMember(Long workspaceId, Long userId, String notFoundMessage) {
        return memberRepository.findByWorkspaceIdAndUserId(workspaceId, userId)
                .orElseThrow(() -> new ResourceNotFoundException(notFoundMessage));
    }

    public WorkspaceMember requireAdminOrOwner(Long workspaceId, Long userId) {
        return requireAdminOrOwner(workspaceId, userId, WORKSPACE_NOT_FOUND);
    }

    public WorkspaceMember requireAdminOrOwner(Long workspaceId, Long userId, String notFoundMessage) {
        WorkspaceMember member = requireMember(workspaceId, userId, notFoundMessage);
        if (member.getRole() == WorkspaceRole.MEMBER) {
            throw new ForbiddenException("Only workspace owners and admins can do this");
        }
        return member;
    }

    public WorkspaceMember requireOwner(Long workspaceId, Long userId) {
        WorkspaceMember member = requireMember(workspaceId, userId);
        if (member.getRole() != WorkspaceRole.OWNER) {
            throw new ForbiddenException("Only the workspace owner can do this");
        }
        return member;
    }

    // ---------------------------------------------------------------- task rules (option B)

    /**
     * OWNER and ADMIN may change any task. A MEMBER may change a task only if they created it, it is assigned
     * to them, or it is unassigned. (Applies to editing, reassigning and moving.)
     */
    public void requireCanModifyTask(WorkspaceMember member, Task task) {
        if (member.getRole() != WorkspaceRole.MEMBER) {
            return;
        }
        Long userId = member.getUser().getId();
        boolean unassigned = task.getAssignee() == null;
        boolean isAssignee = !unassigned && userId.equals(task.getAssignee().getId());
        boolean isCreator = userId.equals(task.getReporter().getId());
        if (!(unassigned || isAssignee || isCreator)) {
            throw new ForbiddenException(
                    "You can only change tasks you created, tasks assigned to you, or unassigned tasks");
        }
    }

    /** OWNER and ADMIN may delete any task; a MEMBER only the tasks they created. */
    public void requireCanDeleteTask(WorkspaceMember member, Task task) {
        if (member.getRole() != WorkspaceRole.MEMBER) {
            return;
        }
        if (!member.getUser().getId().equals(task.getReporter().getId())) {
            throw new ForbiddenException("You can only delete tasks you created");
        }
    }
}
