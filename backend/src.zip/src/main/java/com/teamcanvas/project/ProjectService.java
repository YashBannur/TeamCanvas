package com.teamcanvas.project;

import com.teamcanvas.common.exception.BadRequestException;
import com.teamcanvas.common.exception.ResourceNotFoundException;
import com.teamcanvas.project.dto.CreateProjectRequest;
import com.teamcanvas.project.dto.ProjectResponse;
import com.teamcanvas.project.dto.UpdateProjectRequest;
import com.teamcanvas.security.PermissionService;
import com.teamcanvas.task.TaskRepository;
import com.teamcanvas.task.TaskStatus;
import com.teamcanvas.workspace.WorkspaceMember;
import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProjectService {

    private static final String PROJECT_NOT_FOUND = "Project not found";

    private final ProjectRepository projectRepository;
    private final TaskRepository taskRepository;
    private final PermissionService permissionService;

    public ProjectService(ProjectRepository projectRepository,
                          TaskRepository taskRepository,
                          PermissionService permissionService) {
        this.projectRepository = projectRepository;
        this.taskRepository = taskRepository;
        this.permissionService = permissionService;
    }

    @Transactional
    public ProjectResponse create(Long workspaceId, Long actorId, CreateProjectRequest request) {
        WorkspaceMember actor = permissionService.requireAdminOrOwner(workspaceId, actorId);
        validateDates(request.startDate(), request.dueDate());

        Project project = projectRepository.save(new Project(
                actor.getWorkspace(),
                request.name().trim(),
                blankToNull(request.description()),
                request.startDate(),
                request.dueDate(),
                actor.getUser()));
        return ProjectResponse.from(project, 0, 0);
    }

    /** Any member may list. Only ACTIVE projects are returned unless another status is requested. */
    @Transactional(readOnly = true)
    public List<ProjectResponse> listForWorkspace(Long workspaceId, Long userId, ProjectStatus status) {
        permissionService.requireMember(workspaceId, userId);
        ProjectStatus wanted = status == null ? ProjectStatus.ACTIVE : status;
        List<Project> projects = projectRepository.findByWorkspaceAndStatus(workspaceId, wanted);

        // Progress for ALL listed projects in one extra query (no N+1).
        Map<Long, TaskRepository.ProjectTaskCounts> counts =
                countsFor(projects.stream().map(Project::getId).toList());
        return projects.stream().map(project -> toResponse(project, counts)).toList();
    }

    @Transactional(readOnly = true)
    public ProjectResponse getOne(Long projectId, Long userId) {
        Project project = loadAsMember(projectId, userId);
        return toResponse(project, countsFor(List.of(project.getId())));
    }

    @Transactional
    public ProjectResponse update(Long projectId, Long actorId, UpdateProjectRequest request) {
        Project project = loadAsAdminOrOwner(projectId, actorId);

        if (request.name() != null) {
            project.setName(request.name().trim());
        }
        if (request.description() != null) {
            project.setDescription(blankToNull(request.description()));
        }
        if (request.startDate() != null) {
            project.setStartDate(request.startDate());
        }
        if (request.dueDate() != null) {
            project.setDueDate(request.dueDate());
        }
        // Validate the dates as they will be AFTER the change (a partial update can break the pair).
        validateDates(project.getStartDate(), project.getDueDate());
        if (request.status() != null) {
            project.setStatus(request.status());
        }
        return toResponse(project, countsFor(List.of(project.getId())));
    }

    /** Permanent; the database removes the project's tasks too (ON DELETE CASCADE). */
    @Transactional
    public void delete(Long projectId, Long actorId) {
        Project project = loadAsAdminOrOwner(projectId, actorId);
        projectRepository.delete(project);
    }

    // ---------------------------------------------------------------- access helpers

    /**
     * A missing project and a project in somebody else's workspace both give the same 404, so project ids
     * cannot be probed by changing the id in the URL.
     */
    private Project loadAsMember(Long projectId, Long userId) {
        Project project = findOrThrow(projectId);
        permissionService.requireMember(project.getWorkspace().getId(), userId, PROJECT_NOT_FOUND);
        return project;
    }

    private Project loadAsAdminOrOwner(Long projectId, Long userId) {
        Project project = findOrThrow(projectId);
        permissionService.requireAdminOrOwner(project.getWorkspace().getId(), userId, PROJECT_NOT_FOUND);
        return project;
    }

    private Project findOrThrow(Long projectId) {
        return projectRepository.findDetailedById(projectId)
                .orElseThrow(() -> new ResourceNotFoundException(PROJECT_NOT_FOUND));
    }

    // ---------------------------------------------------------------- progress and validation

    private Map<Long, TaskRepository.ProjectTaskCounts> countsFor(Collection<Long> projectIds) {
        if (projectIds.isEmpty()) {
            return Map.of();
        }
        return taskRepository.countByProjectIds(projectIds, TaskStatus.DONE).stream()
                .collect(Collectors.toMap(TaskRepository.ProjectTaskCounts::getProjectId, Function.identity()));
    }

    private ProjectResponse toResponse(Project project, Map<Long, TaskRepository.ProjectTaskCounts> counts) {
        TaskRepository.ProjectTaskCounts count = counts.get(project.getId());
        if (count == null) {
            return ProjectResponse.from(project, 0, 0);
        }
        return ProjectResponse.from(project, count.getTotal(), count.getCompleted());
    }

    private void validateDates(LocalDate start, LocalDate due) {
        if (start != null && due != null && due.isBefore(start)) {
            throw new BadRequestException("Due date cannot be before start date");
        }
    }

    private String blankToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}
